<?php

$MESS['C_MAIN_PANEL_TEMPLATE_1_SETTINGS_USE'] = 'Использовать глобальные настройки';
$MESS['C_MAIN_PANEL_TEMPLATE_1_PANEL_FIXED'] = 'Не скрывать панель при прокрутке';
$MESS['C_MAIN_PANEL_TEMPLATE_1_PROPERTY_URL'] = 'Свойство "Ссылка"';
$MESS['C_MAIN_PANEL_TEMPLATE_1_PROPERTY_ICON'] = 'Свойство "Иконка"';
$MESS['C_MAIN_PANEL_TEMPLATE_1_NAME_SHOW'] = 'Отображать название элементов';
$MESS['C_MAIN_PANEL_TEMPLATE_1_BASKET_USE'] = 'Использовать корзину';
$MESS['C_MAIN_PANEL_TEMPLATE_1_BASKET_ELEMENT'] = 'Корзина. Элемент';
$MESS['C_MAIN_PANEL_TEMPLATE_1_DELAY_USE'] = 'Использовать отложенные товары';
$MESS['C_MAIN_PANEL_TEMPLATE_1_DELAY_ELEMENT'] = 'Отложенные товары. Элемент';
$MESS['C_MAIN_PANEL_TEMPLATE_1_COMPARE_USE'] = 'Использовать сравнение';
$MESS['C_MAIN_PANEL_TEMPLATE_1_COMPARE_IBLOCK_TYPE'] = 'Сравнение. Тип инфоблока';
$MESS['C_MAIN_PANEL_TEMPLATE_1_COMPARE_IBLOCK_ID'] = 'Сравнение. Инфоблок';
$MESS['C_MAIN_PANEL_TEMPLATE_1_COMPARE_NAME'] = 'Сравнение. Название переменной, в которой хранится список сравнения';
$MESS['C_MAIN_PANEL_TEMPLATE_1_COMPARE_ELEMENT'] = 'Сравнение. Элемент панели, в котором будет отображаться количество товаров';
$MESS['C_MAIN_PANEL_TEMPLATE_1_SVG_COLOR_MODE'] = 'Режим заливки иконки активного элемента (svg)';
$MESS['C_MAIN_PANEL_TEMPLATE_1_SVG_COLOR_MODE_FILL'] = 'fill';
$MESS['C_MAIN_PANEL_TEMPLATE_1_SVG_COLOR_MODE_STROKE'] = 'stroke';
