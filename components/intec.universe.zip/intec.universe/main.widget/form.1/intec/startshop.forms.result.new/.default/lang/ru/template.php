<?php

$MESS['C_FORM_RESULT_NEW_FORM1_CAPTCHA_TITLE'] = 'Введите проверочный код';
$MESS['C_FORM_RESULT_NEW_FORM1_CAPTCHA_PLACEHOLDER'] = 'Код картинки *';
$MESS['C_FORM_RESULT_NEW_FORM1_ERROR_FORM_NOT_EXIST'] = 'Форма не существует';
$MESS['C_FORM_RESULT_NEW_FORM1_ERROR_FORM_UNBOUND'] = 'Форма не принадлежит к данному сайту';
$MESS['C_FORM_RESULT_NEW_FORM1_ERROR_FORM_NO_FIELDS'] = 'У формы нет полей';
$MESS['C_FORM_RESULT_NEW_FORM1_ERROR_EMPTY'] = 'Не заполнено обязательное поле';
$MESS['C_FORM_RESULT_NEW_FORM1_ERROR_INVALID'] = 'Не верно заполнено обязательное поле';
$MESS['C_FORM_RESULT_NEW_FORM1_CAPTCHA_ERROR'] = 'Проверочный код введен не верно';
$MESS['C_FORM_RESULT_NEW_FORM1_CONSENT_TEXT'] = 'Я согласен(а) на <a href="#URL#" target="_blank">обработку персональных данных</a>';