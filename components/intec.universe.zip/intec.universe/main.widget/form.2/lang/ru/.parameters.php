<?php

$MESS['C_WIDGET_FORM_2_WEB_FORM_ID'] = 'Форма';
$MESS['C_WIDGET_FORM_2_SETTINGS_USE'] = 'Использовать глобальные настройки';
$MESS['C_WIDGET_FORM_2_WEB_FORM_CONSENT_LINK'] = 'Ссылка на страницу с соглашением';
$MESS['C_WIDGET_FORM_2_WEB_FORM_TITLE_SHOW'] = 'Показывать заголовок формы';
$MESS['C_WIDGET_FORM_2_WEB_FORM_TITLE_POSITION'] = 'Расположение заголовка формы';
$MESS['C_WIDGET_FORM_2_WEB_FORM_DESCRIPTION_SHOW'] = 'Показывать описание формы';
$MESS['C_WIDGET_FORM_2_WEB_FORM_DESCRIPTION_POSITION'] = 'Расположение описания формы';
$MESS['C_WIDGET_FORM_2_WEB_FORM_THEME'] = 'Цвет текста';
$MESS['C_WIDGET_FORM_2_WEB_FORM_BUTTON_POSITION'] = 'Расположение кнопки отправки формы';
$MESS['C_WIDGET_FORM_2_WEB_FORM_BACKGROUND_USE'] = 'Использовать заливку формы';
$MESS['C_WIDGET_FORM_2_WEB_FORM_BACKGROUND_COLOR'] = 'Цвет заливки формы';
$MESS['C_WIDGET_FORM_2_WEB_FORM_BACKGROUND_COLOR_CUSTOM'] = 'Ваш цвет заливки формы';
$MESS['C_WIDGET_FORM_2_WEB_FORM_BACKGROUND_OPACITY'] = 'Прозрачность заливки формы (%)';
$MESS['C_WIDGET_FORM_2_WEB_FORM_CONSENT_SHOW'] = 'Показывать ссылку на соглашение';

$MESS['C_WIDGET_FORM_2_WEB_FORM_THEME_DARK'] = 'Темный';
$MESS['C_WIDGET_FORM_2_WEB_FORM_THEME_LIGHT'] = 'Светлый';

$MESS['C_WIDGET_FORM_2_WEB_FORM_COLOR_THEME'] = 'Цвет темы сайта';
$MESS['C_WIDGET_FORM_2_WEB_FORM_COLOR_CUSTOM'] = 'Свой цвет';

$MESS['C_WIDGET_FORM_2_WEB_FORM_POSITION_LEFT'] = 'Слева';
$MESS['C_WIDGET_FORM_2_WEB_FORM_POSITION_CENTER'] = 'По центру';
$MESS['C_WIDGET_FORM_2_WEB_FORM_POSITION_RIGHT'] = 'Справа';

$MESS['C_WIDGET_FORM_2_WEB_FORM_CONSENT_SHOW_Y'] = 'Да';
$MESS['C_WIDGET_FORM_2_WEB_FORM_CONSENT_SHOW_N'] = 'Нет';
$MESS['C_WIDGET_FORM_2_WEB_FORM_CONSENT_SHOW_PARAMETERS'] = 'Использовать настройки сайта';