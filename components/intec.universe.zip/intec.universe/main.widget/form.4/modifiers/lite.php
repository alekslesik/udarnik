<?php if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use intec\core\collections\Arrays;

/**
 * @var array $arResult
 * @var array $arParams
 */

$arResult['WEB_FORM'] = Arrays::fromDBResult(CStartShopForm::GetByID($arParams['FORM_ID']))->getFirst();