<?php

$MESS['C_WIDGET_FORM_5_FORM_ID'] = 'Веб форма';
$MESS['C_WIDGET_FORM_5_FORM_TEMPLATE'] = 'Шаблон веб формы';
$MESS['C_WIDGET_FORM_5_FORM_TITLE'] = 'Текст заголовка формы';
$MESS['C_WIDGET_FORM_5_SETTINGS_USE'] = 'Использовать глобальные настройки';
$MESS['C_WIDGET_FORM_5_CONSENT_SHOW'] = 'Отображать соглашение на обработку данных';
$MESS['C_WIDGET_FORM_5_CONSENT_URL'] = 'Соглашение на обработку данных. Ссылка';
$MESS['C_WIDGET_FORM_5_WIDE'] = 'Блок. На ширину экрана';
$MESS['C_WIDGET_FORM_5_BORDER_STYLE'] = 'Блок. Стиль границ';
$MESS['C_WIDGET_FORM_5_BORDER_STYLE_SQUARED'] = 'Прямые углы';
$MESS['C_WIDGET_FORM_5_BORDER_STYLE_ROUNDED'] = 'Скруглённые углы';
$MESS['C_WIDGET_FORM_5_TITLE'] = 'Блок. Заголовок';
$MESS['C_WIDGET_FORM_5_DESCRIPTION'] = 'Блок. Описание';
$MESS['C_WIDGET_FORM_5_BUTTON'] = 'Блок. Текст кнопки';
