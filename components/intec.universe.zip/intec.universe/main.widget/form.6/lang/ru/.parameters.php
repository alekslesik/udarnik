<?php

$MESS['C_WIDGET_FORM_6_FORM_ID'] = 'Веб форма';
$MESS['C_WIDGET_FORM_6_FORM_TEMPLATE'] = 'Шаблон веб формы';
$MESS['C_WIDGET_FORM_6_FORM_TITLE'] = 'Текст заголовка формы';
$MESS['C_WIDGET_FORM_6_SETTINGS_USE'] = 'Использовать глобальные настройки';
$MESS['C_WIDGET_FORM_6_CONSENT_SHOW'] = 'Отображать соглашение на обработку данных';
$MESS['C_WIDGET_FORM_6_CONSENT_URL'] = 'Соглашение на обработку данных. Ссылка';
$MESS['C_WIDGET_FORM_6_WIDE'] = 'Блок. На ширину экрана';
$MESS['C_WIDGET_FORM_6_BORDER_STYLE'] = 'Блок. Стиль границ';
$MESS['C_WIDGET_FORM_6_BORDER_STYLE_SQUARED'] = 'Прямые углы';
$MESS['C_WIDGET_FORM_6_BORDER_STYLE_ROUNDED'] = 'Скруглённые углы';
$MESS['C_WIDGET_FORM_6_TITLE'] = 'Блок. Заголовок';
$MESS['C_WIDGET_FORM_6_DESCRIPTION'] = 'Блок. Описание';
$MESS['C_WIDGET_FORM_6_BUTTON'] = 'Блок. Текст кнопки';