<?php

$MESS['C_WIDGET_FORM_7_FORM_ID'] = 'Веб форма';
$MESS['C_WIDGET_FORM_7_FORM_TEMPLATE'] = 'Шаблон веб формы';
$MESS['C_WIDGET_FORM_7_FORM_TITLE'] = 'Текст заголовка формы';
$MESS['C_WIDGET_FORM_7_SETTINGS_USE'] = 'Использовать глобальные настройки';
$MESS['C_WIDGET_FORM_7_CONSENT_SHOW'] = 'Отображать соглашение на обработку данных';
$MESS['C_WIDGET_FORM_7_CONSENT_URL'] = 'Соглашение на обработку данных. Ссылка';
$MESS['C_WIDGET_FORM_7_WIDE'] = 'Блок. На ширину экрана';
$MESS['C_WIDGET_FORM_7_BORDER_STYLE'] = 'Блок. Стиль границ';
$MESS['C_WIDGET_FORM_7_BORDER_STYLE_SQUARED'] = 'Прямые углы';
$MESS['C_WIDGET_FORM_7_BORDER_STYLE_ROUNDED'] = 'Скруглённые углы';
$MESS['C_WIDGET_FORM_7_TITLE'] = 'Блок. Заголовок';
$MESS['C_WIDGET_FORM_7_DESCRIPTION'] = 'Блок. Описание';
$MESS['C_WIDGET_FORM_7_BUTTON'] = 'Блок. Текст кнопки';