<?php

$MESS['C_WIDGET_FORM_8_FORM_ID'] = 'Форма';
$MESS['C_WIDGET_FORM_8_SETTINGS_USE'] = 'Использовать глобальные настройки';
$MESS['C_WIDGET_FORM_8_LAZYLOAD_USE'] = 'Использовать "ленивую загрузку" изображений';
$MESS['C_WIDGET_FORM_8_CONSENT_SHOW'] = 'Отображать соглашение на обработку данных';
$MESS['C_WIDGET_FORM_8_CONSENT_URL'] = 'Ссылка на страницу соглашения на обработку данных';
$MESS['C_WIDGET_FORM_8_FORM_TITLE_SHOW'] = 'Показывать заголовок формы';
$MESS['C_WIDGET_FORM_8_FORM_DESCRIPTION_SHOW'] = 'Показывать описание формы';
$MESS['C_WIDGET_FORM_8_FORM_ADDITIONAL_PICTURE_SHOW'] = 'Показывать доп. изображение';
$MESS['C_WIDGET_FORM_8_FORM_ADDITIONAL_PICTURE_PATH'] = 'Путь до доп. картинки';
$MESS['C_WIDGET_FORM_8_FORM_ADDITIONAL_PICTURE_SIZE'] = 'Тип масштабирования доп. изображения';
$MESS['C_WIDGET_FORM_8_FORM_ADDITIONAL_PICTURE_SIZE_COVER'] = 'Вписать';
$MESS['C_WIDGET_FORM_8_FORM_ADDITIONAL_PICTURE_SIZE_CONTAIN'] = 'Уместить';
$MESS['C_WIDGET_FORM_8_FORM_ADDITIONAL_PICTURE_VERTICAL'] = 'Вертикальное положение доп. картинки';
$MESS['C_WIDGET_FORM_8_FORM_ADDITIONAL_PICTURE_VERTICAL_TOP'] = 'Сверху';
$MESS['C_WIDGET_FORM_8_FORM_ADDITIONAL_PICTURE_VERTICAL_CENTER'] = 'По центру';
$MESS['C_WIDGET_FORM_8_FORM_ADDITIONAL_PICTURE_VERTICAL_BOTTOM'] = 'Снизу';
$MESS['C_WIDGET_FORM_8_FORM_POSITION'] = 'Расположение формы';
$MESS['C_WIDGET_FORM_8_FORM_POSITION_LEFT'] = 'Слева';
$MESS['C_WIDGET_FORM_8_FORM_POSITION_RIGHT'] = 'Справа';
$MESS['C_WIDGET_FORM_8_FORM_POSITION_CENTER'] = 'По центру';
$MESS['C_WIDGET_FORM_8_FORM_BACKGROUND_PATH'] = 'Путь до картинки фона для блока';
$MESS['C_WIDGET_FORM_8_FORM_BACKGROUND_PARALLAX_USE'] = 'Использовать эффект паралакса';
$MESS['C_WIDGET_FORM_8_FORM_BACKGROUND_PARALLAX_RATIO'] = 'Сила эффекта паралакса (0 - 100)';