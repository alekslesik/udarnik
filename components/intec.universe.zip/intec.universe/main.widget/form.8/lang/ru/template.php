<?php

$MESS['C_WIDGET_FORM_8_TEMPLATE_ERROR'] = 'Ошибка при вызове компонента';