<?php

$MESS['C_MAIN_WIDGET_BUTTON_TOP_BORDER_RADIUS'] = 'Радиус скругления углов кнопки';