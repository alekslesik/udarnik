<?php

$MESS['C_SYSTEM_SETTINGS_VARIABLES_VARIANT'] = 'Переменная, в которой передается вариант выбора';