<?php if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die() ?>
<?php

$arViews['boolean'] = include(__DIR__.'/views/boolean.php');
$arViews['blocks'] = include(__DIR__.'/views/blocks.php');
$arViews['color'] = include(__DIR__.'/views/color.php');
$arViews['list'] = include(__DIR__.'/views/list.php');
$arViews['list.template'] = include(__DIR__.'/views/list.template.php');